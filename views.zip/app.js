// var createError = require("http-errors");
var express = require("express");
var path = require("path");
var app = express();
const cors = require("cors");
const session = require("express-session");
const fileUpload = require("express-fileupload");

app.use(cors());
app.use(express.json());
app.use(
  session({
    secret: "abcd1234key",
    resave: false,
    saveUninitialized: false,
  })
);
app.use(fileUpload());

// app.set('view engine', 'html');
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");

var bulkMailSend = require("./apis/MailSend/BulkMailSend");

app.use("/apis/MailSend/BulkMailSend", bulkMailSend);

// app.use(express.static(__dirname + "/assets/tax_documents"));

app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error", {
    message: err.message,
    error: err,
  });
});

module.exports = app;
